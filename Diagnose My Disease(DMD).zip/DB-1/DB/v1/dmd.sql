-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 02, 2016 at 01:37 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dmd`
--
CREATE DATABASE IF NOT EXISTS `dmd` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dmd`;

-- --------------------------------------------------------

--
-- Table structure for table `diagnose`
--

CREATE TABLE IF NOT EXISTS `diagnose` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uId` int(11) NOT NULL,
  `diseasId` int(11) NOT NULL,
  `digSol` varchar(3000) NOT NULL DEFAULT '',
  `quickMedi` varchar(3000) NOT NULL DEFAULT '',
  `docRef` varchar(1000) NOT NULL DEFAULT '',
  `isActive` int(1) NOT NULL DEFAULT '1',
  `whenEntered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uId` (`uId`),
  KEY `diseasId` (`diseasId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `diseas`
--

CREATE TABLE IF NOT EXISTS `diseas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dName` varchar(100) NOT NULL DEFAULT '',
  `dSymptoms` varchar(500) NOT NULL DEFAULT '',
  `dDescription` varchar(3000) NOT NULL DEFAULT '',
  `uId` int(255) NOT NULL,
  `dPic` varchar(1000) NOT NULL DEFAULT '',
  `whenEtered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uId` (`uId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `dob` varchar(12) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `mobileNumber` int(10) DEFAULT NULL,
  `emailId` varchar(50) DEFAULT NULL,
  `uPassword` varchar(50) NOT NULL DEFAULT '',
  `whenEntered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isActive` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `diagnose`
--
ALTER TABLE `diagnose`
  ADD CONSTRAINT `disFk` FOREIGN KEY (`diseasId`) REFERENCES `diseas` (`id`),
  ADD CONSTRAINT `userDiagFK` FOREIGN KEY (`uId`) REFERENCES `user` (`id`);

--
-- Constraints for table `diseas`
--
ALTER TABLE `diseas`
  ADD CONSTRAINT `userDisFk` FOREIGN KEY (`uId`) REFERENCES `user` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
