<?php
 
/*
 * Following code will update a product information
 * A product is identified by product id (pid)
 */
 
// array for JSON response
$response = array();
 
// check for required fields
if (isset($_POST['id']) && isset($_POST['dName']) && isset($_POST['dSymptoms']) && isset($_POST['dDescription'])&& isset($_POST['dPic'])) {
 
    $id = $_POST['id'];
    $dName = $_POST['dName'];
    $dSymptoms = $_POST['dSymptoms'];
    $dDescription = $_POST['dDescription'];
	$dPic = $_POST['dPic'];
    // include db connect class
    require_once __DIR__ . '/db_connect.php';
 
    // connecting to db
    $db = new DB_CONNECT();
 
    // mysql update row with matched pid
    $result = mysql_query("UPDATE diseas SET dName = '$dName', dSymptoms = '$dSymptoms', dDescription = '$dDescription', dPic = '$dPic' WHERE id = $id");
 
    // check if row inserted or not
    if ($result) {
        // successfully updated
        $response["success"] = 1;
        $response["message"] = "successfully updated.";
 
        // echoing JSON response
        echo json_encode($response);
    } else {
 
    }
} else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Error while updating";
 
    // echoing JSON response
    echo json_encode($response);
}
?>