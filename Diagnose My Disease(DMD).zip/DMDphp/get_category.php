<?php
//include_once './DB_CONNECT.php';
 // include db connect class
    require_once __DIR__ . '/db_connect.php';

    // connecting to db
    $db = new DB_CONNECT();
//function getCategories(){
   // $db = new DB_CONNECT();
    // array for json response
    $response = array();
    $response["categories"] = array();
    
    // Mysql select query
    $result = mysql_query("SELECT cate_type FROM `category`");
    
    while($row = mysql_fetch_array($result)){
        // temporary array to create single category
        $tmp = array();
       // $tmp["id"] = $row["id"];
        $tmp["cate_type"] = $row["cate_type"];
        
        // push category to final json array
        array_push($response["categories"], $tmp);
    }
    
    // keeping response header to json
   // header('Content-Type: application/json');
    
    // echoing json result
    echo json_encode($response);
//}


?>