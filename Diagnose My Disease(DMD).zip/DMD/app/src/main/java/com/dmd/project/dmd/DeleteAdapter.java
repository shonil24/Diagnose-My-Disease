package com.dmd.project.dmd;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by GreatCoder on 2/7/2016.
 */
public class DeleteAdapter  extends ArrayAdapter<DeletePOJO> {


    Context context;
    int layoutResourceId;
    ArrayList<DeletePOJO> data = new ArrayList<DeletePOJO>();
    PhotosFragment vd;
    Activity a;

    SharedPreferences sp;

    static String disId;

    public DeleteAdapter(Context context, int layoutResourceId,
                             ArrayList<DeletePOJO> data,Activity rec) {
        super(context, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.context = context;
        this.data = data;
        a=rec;

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        UserHolder holder = null;

        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(layoutResourceId, parent, false);
            holder = new UserHolder();
            holder.textName = (TextView) row.findViewById(R.id.textView1);//name
            holder.textAddress = (TextView) row.findViewById(R.id.textView2);//symptoms
            holder.textLocation = (TextView) row.findViewById(R.id.textView3);//user id

            holder.btnDelete = (ImageView) row.findViewById(R.id.button2);
            holder.imageView = (ImageView) row.findViewById(R.id.imageview1);


                row.setTag(holder);
        }
        else {
            holder = (UserHolder) row.getTag();
        }
        final DeletePOJO deleteObj = data.get(position);
        holder.textName.setText(deleteObj.getName());
        holder.textAddress.setText(deleteObj.getAddress());
        holder.textLocation.setText(deleteObj.getLocation());
       // holder.imageView.setImageResource(deleteObj.iconid());

        //making delete button enable n disable
        sp = a.getSharedPreferences(RefLink.prefStoreName,
                Context.MODE_PRIVATE);
        if(!sp.getString("Uid","").equals(deleteObj.getLocation())) {
            holder.btnDelete.setVisibility(View.INVISIBLE);
        }
        else
        {
            holder.btnDelete.setVisibility(View.VISIBLE);
        }

        Picasso
                .with(context)
                .load(RefLink.imageDownloadPath+deleteObj.getImagePath())
                .fit() // will explain later
                .into(holder.imageView);

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Log.i("Delete Button Clicked", "**********");
                Toast.makeText(context, "Delete button Clicked",
                        Toast.LENGTH_LONG).show();

                disId=deleteObj.getid();
              //  DeleteDiseas(deleteObj,context);

                //to remove data from array list
               // data.remove(deleteObj);
                //to notify/say list view that data has been changed
               // notifyDataSetChanged();

                AddEmployee ae = new AddEmployee();
                ae.execute();


                a.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //to remove data from array list
                        data.remove(deleteObj);
                        //to notify/say list view that data has been changed
                        notifyDataSetChanged();

                    }
                });


            }
        });

       /* holder.imageView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Log.i("image Clicked", "**********");
                Toast.makeText(context, "image Clicked",
                        Toast.LENGTH_LONG).show();
            }
        });*/
        return row;

    }

    static class UserHolder {
        TextView textName;
        TextView textAddress;
        TextView textLocation;
        ImageView btnDelete;
        ImageView imageView;
    }

    //private void DeleteDiseas(DeletePOJO DeleteObj, final Context ctx){

       class AddEmployee extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(a,"checking...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                String dataReceived=s;
                try {
                    JSONObject root = new JSONObject(dataReceived.toString());
                    String status=root.getString("success");
                    Toast.makeText(context, ' ' + status, Toast.LENGTH_LONG).show();

                    if(Integer.parseInt(status)==1)
                    {
                        Toast.makeText(context,' '+status, Toast.LENGTH_LONG).show();

                    }else
                    {
                        Toast.makeText(context,"Try again!!!", Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e)
                {
                    Toast.makeText(context,"Error="+e,Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                params.put("Did",disId);//"1");

                RequestHandler rh = new RequestHandler();
                //String res = rh.sendPostRequest("http://10.0.2.2:80/DMDphp/v1/deleteDiseas.php", params);
                String res = rh.sendPostRequest(RefLink.urlDeleteDis, params);
                System.out.println("Res="+res);
                return res;
            }
        }

       // AddEmployee ae = new AddEmployee();
      //  ae.execute();
   // }

}