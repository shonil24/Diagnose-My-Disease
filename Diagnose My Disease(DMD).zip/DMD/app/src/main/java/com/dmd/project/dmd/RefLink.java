package com.dmd.project.dmd;

/**
 * Created by GreatCoder on 3/13/2016.
 */
public class RefLink {

    static String prefStoreName= "my_db";
    //ipaddress of your laptop connected to internet and assign ipv4 address where default gateway is written as 192.168.1.1 and :80 is port number through which your app and server communicate and it is default port which is using in wamp server
    //192.168.1.45:8080//
    static String ipAddress="192.168.4.117:80";
    static String urlPrefix="http://";

    static String imageDownloadPath=urlPrefix+ipAddress+"/DMDphp/v1/uploadedimages/";

    static String urlLogin=urlPrefix+ipAddress+"/DMDphp/v1/Login.php";
    static String urlSignUp=urlPrefix+ipAddress+"/DMDphp/v1/SignUp.php";

    static String urlUploadImage=urlPrefix+ipAddress+"/DMDphp/v1/uploadImage.php";
    static String urlAddnewDis=urlPrefix+ipAddress+"/DMDphp/v1/new_Diseas_Entry.php";

    static String urlGetAllDis=urlPrefix+ipAddress+"/DMDphp/v1/get_All_Dis.php";
    static String urlGetAllDisDiagno=urlPrefix+ipAddress+"/DMDphp/v1/get_DisDiagnos.php";
    static String urlUpdateDis=urlPrefix+ipAddress+"/DMDphp/v1/updateDiseas.php";
    static String urlAnswerDis=urlPrefix+ipAddress+"/DMDphp/v1/newDiseasDiagnos.php";
    static String urlDeleteDiagno=urlPrefix+ipAddress+"/DMDphp/v1/deleteDiagnos.php";

    static String urlDeleteDis=urlPrefix+ipAddress+"/DMDphp/v1/deleteDiseas.php";




}
