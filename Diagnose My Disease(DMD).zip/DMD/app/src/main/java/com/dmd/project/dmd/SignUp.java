package com.dmd.project.dmd;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.dmd.project.dmd.model.NavDrawerItem;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by GreatCoder on 1/24/2016.
 */
public class SignUp extends Activity implements View.OnClickListener{

    Button signUpUser,clearUserData;

    EditText userName,userDOB,userContact,userEmail,userPass;

    String[] navMenuTitles;
    TypedArray navMenuIcons;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        userName=(EditText)findViewById(R.id.et_name);
        userDOB=(EditText)findViewById(R.id.et_date);
        userContact=(EditText)findViewById(R.id.et_phone);
        userEmail=(EditText)findViewById(R.id.et_email_Signup);
        userPass=(EditText)findViewById(R.id.et_password);

        signUpUser= (Button) findViewById(R.id.btn_signup);
        clearUserData = (Button) findViewById(R.id.btn_clear_signup);

        userName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!(userName.getText().toString().trim().equals(""))) {
                    userName.setError(null);
                    // Toast.makeText(getApplicationContext(), "Enter Id",
                    // Toast.LENGTH_SHORT).show();
                } else {
                    if (userName.getText().toString().trim().equals("")) {
                        userName.setError("Enter user name");
                        // Toast.makeText(getApplicationContext(), "Enter Id",
                        // Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        userDOB.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!(userDOB.getText().toString().trim().equals(""))) {
                    userDOB.setError(null);
                    // Toast.makeText(getApplicationContext(), "Enter Id",
                    // Toast.LENGTH_SHORT).show();
                } else {
                    if (userDOB.getText().toString().trim().equals("")) {
                        userDOB.setError("Enter DOB");
                        // Toast.makeText(getApplicationContext(), "Enter Id",
                        // Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        userContact.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!(userContact.getText().toString().trim().equals(""))) {
                    userContact.setError(null);
                    // Toast.makeText(getApplicationContext(), "Enter Id",
                    // Toast.LENGTH_SHORT).show();
                } else {
                    if (userContact.getText().toString().trim().equals("")) {
                        userContact.setError("Enter contact no.");
                        // Toast.makeText(getApplicationContext(), "Enter Id",
                        // Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        userEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!(userEmail.getText().toString().trim().equals(""))) {
                    userEmail.setError(null);
                    // Toast.makeText(getApplicationContext(), "Enter Id",
                    // Toast.LENGTH_SHORT).show();
                } else {
                    if (userEmail.getText().toString().trim().equals("")) {
                        userEmail.setError("Enter email id");
                        // Toast.makeText(getApplicationContext(), "Enter Id",
                        // Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        userPass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!(userPass.getText().toString().trim().equals(""))) {
                    userPass.setError(null);
                    // Toast.makeText(getApplicationContext(), "Enter Id",
                    // Toast.LENGTH_SHORT).show();
                } else {
                    if (userPass.getText().toString().trim().equals("")) {
                        userPass.setError("Enter password");
                        // Toast.makeText(getApplicationContext(), "Enter Id",
                        // Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //assigning event listener
        signUpUser.setOnClickListener(this);
        clearUserData.setOnClickListener(this);
    }

    //email validation code
    public static boolean isEmailValid(String email) {
        boolean isValid = false;

        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        CharSequence inputStr = email;

        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches()) {
            isValid = true;
        }
        return isValid;
    }



    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.btn_signup:

                DateFormatValidator dateFormatValidator= new DateFormatValidator();

                String msg="Enter ";
                // Call service here
                if(userName.getText().toString().trim().equals("") || userName.getText().toString().length()<9){
                    msg+=" User Name,";
                }
                if(userDOB.getText().toString().trim().equals("") || dateFormatValidator.validate(userDOB.getText().toString())==false){
                    msg+="  valid DOB,";
                }
                if(userContact.getText().toString().trim().equals("") || userContact.getText().toString().length()!=10){
                    msg+="  valid contact no. ,";
                }
                if(userEmail.getText().toString().trim().equals("") || isEmailValid(userEmail.getText().toString().trim())==false){
                    msg+="  email id,";
                }
                if(userPass.getText().toString().trim().equals("") || userPass.getText().toString().length()<9){
                    msg+=" password";
                }

                if(msg.equals("Enter "))
                {
                    msg="";
                }

                if(msg.length()!=0){
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                }else{
                    RegisterNewUser();
                }


                break;

            case R.id.btn_clear_signup:
                clearAllRegData();
                break;
        }
    }

    public void clearAllRegData() {
        userName.setText("");
        userDOB.setText("");
        userContact.setText("");
        userEmail.setText("");
        userPass.setText("");


        userName.setError(null);
        userDOB.setError(null);
        userContact.setError(null);
        userEmail.setError(null);
        userPass.setError(null);


    }


    //Registering new user
    private void RegisterNewUser(){



        class AddEmployee extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            String userSignName=userName.getText().toString();
            String userSignDOB=userDOB.getText().toString();
            String userContactNo=userContact.getText().toString();
            String userEmailID=userEmail.getText().toString();
            String userPassword=userPass.getText().toString();



            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(SignUp.this,"checking...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                String dataReceived=s;
                try {
                    JSONObject root = new JSONObject(dataReceived.toString());
                    String status=root.getString("success");
                    Toast.makeText(SignUp.this, ' ' + status, Toast.LENGTH_LONG).show();

                    if(Integer.parseInt(status)==1)
                    {
                        Toast.makeText(SignUp.this,' '+status, Toast.LENGTH_LONG).show();

                        // INSTANTIATE SHARED PREFERENCES CLASS
                        SharedPreferences sp = getSharedPreferences(RefLink.prefStoreName,
                                Context.MODE_PRIVATE);
                        // LOAD THE EDITOR – REMEMBER TO COMMIT CHANGES!
                        SharedPreferences.Editor e = sp.edit();
                        e.putString("Uid", root.getString("id"));
                        e.putString("Uname", root.getString("name"));
                        e.putString("Uemail", userEmailID);
                        e.putString("Upassword", userPassword);

                        e.commit();

                        // load slide menu items
                        navMenuTitles = getResources().getStringArray(R.array.nav_drawer_items);

                        // nav drawer icons from resources
                        navMenuIcons = getResources()
                                .obtainTypedArray(R.array.nav_drawer_icons);


                        MainActivity m=new MainActivity();

                        navMenuTitles[5]="Logout";
                        // navMenuIcons.getResourceId(5, R.drawable.logout);

                        //navDrawerItems.add(new NavDrawerItem(navMenuTitles[5], navMenuIcons.getResourceId(5, -1)));


                        MainActivity.copyList.set(5, new NavDrawerItem(navMenuTitles[5], navMenuIcons.getResourceId(6, -1)));

                        m.navDrawerItems=MainActivity.copyList;



                        Login l=new Login();
                        l.finish();
                        finish();

                    }else
                    {
                        Toast.makeText(SignUp.this,"Try again!!!", Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e)
                {
                    Toast.makeText(SignUp.this,"Error="+e,Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                params.put("userSignName",userSignName);
                params.put("userSignDOB",userSignDOB);
                params.put("userContactNo",userContactNo);
                params.put("userEmailID",userEmailID);
                params.put("userPassword",userPassword);


                RequestHandler rh = new RequestHandler();

                String res = rh.sendPostRequest(RefLink.urlSignUp, params);
                //String res = rh.sendPostRequest("http://10.0.2.2:80/DMDphp/v1/SignUp.php", params);

                System.out.println("Res="+res);
                return res;
            }
        }

        AddEmployee ae = new AddEmployee();
        ae.execute();
    }


}
