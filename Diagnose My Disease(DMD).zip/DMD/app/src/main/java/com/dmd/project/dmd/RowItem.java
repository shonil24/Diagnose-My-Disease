package com.dmd.project.dmd;

import android.graphics.Bitmap;

/**
 * Created by GreatCoder on 1/31/2016.
 */
public class RowItem {
    private String Id;
    private String title;
    private String sympt;
    private String desc;
    private String uId;
    private String uName;
    private int imageId;
    private String imagePath;



    public RowItem(String Id, String title, String sympt,String desc,String uId,String uName,int imageId) {
        this.Id = Id;
        this.title = title;
        this.sympt = sympt;
        this.desc = desc;
        this.uId = uId;
        this.uName = uName;
        this.imageId = imageId;
    }

    public RowItem(String Id, String title, String sympt,String desc,String uId,String uName,String imagePath) {
        this.Id = Id;
        this.title = title;
        this.sympt = sympt;
        this.desc = desc;
        this.uId = uId;
        this.uName = uName;
        this.imagePath = imagePath;
    }

    //image
    public int getImageId() {
        return imageId;
    }
    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    //image
    public String getImagePath() {
        return imagePath;
    }
    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    //user id

    public String getUserId()
    {
        return uId;
    }
    public void setUserId(String uId) {
        this.uId = uId;
    }
    //userName

    public String getUserName() {
        return uName;
    }
    public void setUserName(String uName) {
        this.uName = uName;
    }

    //desc
    public String getDesc() {
        return desc;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }

    //symptoms
    public String getsympt() {
        return sympt;
    }
    public void setsympt(String sympt) {
        this.sympt = sympt;
    }

    //diseas Name
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    //_id
    public String getId()
    {
        return Id;
    }
    public void setId(String Id) {
        this.Id = Id;
    }

    @Override
    public String toString() {
        return title + "\n" + desc;
    }
}
