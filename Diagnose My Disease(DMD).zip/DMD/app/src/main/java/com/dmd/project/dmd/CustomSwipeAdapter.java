package com.dmd.project.dmd;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

/**
 * Created by GreatCoder on 1/8/2016.
 */
public class CustomSwipeAdapter extends PagerAdapter {

    private int[] images_resources={R.drawable.healthcaresymbol,R.drawable.healthcare,R.drawable.nursing_ad,R.drawable.statiscope,R.drawable.tablets,R.drawable.save_earth_health};
    private Context ctx;
    private LayoutInflater layoutInflater;

    public CustomSwipeAdapter(Context ctx)
    {
        this.ctx=ctx;
    }

    @Override
    public int getCount() {
        return images_resources.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return (view==(LinearLayout)object);
    }
    @Override
    public Object instantiateItem(ViewGroup container,int position)
    {
        //inflating layout
        layoutInflater=(LayoutInflater)ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View items_view=layoutInflater.inflate(R.layout.swipelayout,container,false);

        //creating object of image view
        ImageView imageView=(ImageView)items_view.findViewById(R.id.imagesToView);

        //set the resources to imagesview
        imageView.setImageResource(images_resources[position]);

        //adding view on container
        container.addView(items_view);

        //returning item view object
        return items_view;
    }
    @Override
    public void destroyItem(ViewGroup container,int position,Object object)
    {
       // super.destroyItem(container, position,object);
        //destroy the image view when user move from one slide to another so it will release some heap memory
        container.removeView((LinearLayout)object);


    }

}
