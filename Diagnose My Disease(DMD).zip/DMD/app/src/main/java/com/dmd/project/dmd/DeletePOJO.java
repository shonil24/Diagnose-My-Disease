package com.dmd.project.dmd;

/**
 * Created by GreatCoder on 2/7/2016.
 */
public class DeletePOJO {

    String id;
    String name;
    String address;
    String location;
    private String imagePath;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getid() {
        return id;
    }

    public void setid(String id) {
        this.id = id;
    }

    //image
    public String getImagePath() {
        return imagePath;
    }
    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }


    public DeletePOJO(String id, String name, String address, String location) {
        super();
        this.id=id;
        this.name = name;
        this.address = address;
        this.location = location;
    }
                        //image path,dis id,dis name,dis symp,userid
    public DeletePOJO(String imagePath, String id ,String name, String address, String location) {
        super();
        this.id=id;
        this.imagePath = imagePath;
        this.name = name;
        this.address = address;
        this.location = location;

    }

}
