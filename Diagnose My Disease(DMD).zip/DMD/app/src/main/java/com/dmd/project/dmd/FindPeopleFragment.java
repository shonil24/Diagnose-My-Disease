package com.dmd.project.dmd;

import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class FindPeopleFragment extends Fragment implements
        AdapterView.OnItemClickListener {

    public static final String[] titles = new String[] { "James",
            "Smith", "Jack", "Adolf" };

    public static final String[] descriptions = new String[] {
            "Allergies",
            "Back pain", "Colds",
            "Lung cancer" };

    public static final Integer[] images = { R.drawable.diseas,
            R.drawable.diseas, R.drawable.diseas, R.drawable.diseas };

    ListView listView;
    List<RowItem> rowItems;
    EditText txtSearch;

	public FindPeopleFragment(){}
	
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
 
        View rootView = inflater.inflate(R.layout.fragment_find_people, container, false);


        getAllDiseas(rootView);

        /*txtSearch=(EditText)rootView.findViewById(R.id.edtSearchText);

        rowItems = new ArrayList<RowItem>();
        for (int i = 0; i < titles.length; i++) {
            RowItem item = new RowItem(images[i], titles[i], descriptions[i]);
            rowItems.add(item);
        }



        listView = (ListView) rootView.findViewById(R.id.list);
        final CustomListViewDMDAdapter adapter = new CustomListViewDMDAdapter(getActivity().getApplicationContext(),
                R.layout.viewitems, rowItems);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);

        txtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String text = txtSearch.getText().toString().toLowerCase(Locale.getDefault());
                adapter.filter(text);

            }
        });*/



        return rootView;
    }

    public void createListData(View rootView,String dataReceived) throws JSONException, IOException {
        JSONObject root = new JSONObject(dataReceived.toString());
        JSONArray jArr = root.getJSONArray("diseas");
        txtSearch=(EditText)rootView.findViewById(R.id.edtSearchText);

        rowItems = new ArrayList<RowItem>();
       /* for (int i = 0; i < titles.length; i++) {
            RowItem item = new RowItem(images[i], titles[i], descriptions[i]);
            rowItems.add(item);
        }*/
        for (int i = 0; i < jArr.length(); i++) {

            JSONObject Arrdata = jArr.getJSONObject(i);

            RowItem item = new RowItem(Arrdata.getString("id"), Arrdata.getString("dName"), Arrdata.getString("dSymptoms"), Arrdata.getString("dDescription"), Arrdata.getString("uId"), Arrdata.getString("uName"),((Arrdata.getString("dPic"))));//Arrdata.getString("dPic")
            rowItems.add(item);
        }

        listView = (ListView) rootView.findViewById(R.id.list);
        final CustomListViewDMDAdapter adapter = new CustomListViewDMDAdapter(getActivity().getApplicationContext(),
                R.layout.viewitems, rowItems);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);

        txtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String text = txtSearch.getText().toString().toLowerCase(Locale.getDefault());
                adapter.filter(text);

            }
        });

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position,
                            long id) {

        Intent ViewDetail=new Intent(getActivity().getApplicationContext(),ViewDetailDisAns.class);

        //passing data
        //Create a bundle object
        Bundle b = new Bundle();

        //Inserts a String value into the mapping of this Bundle
        b.putString("disId",rowItems.get(position).getId());
        b.putString("disName",rowItems.get(position).getTitle());
        b.putString("disSympt", rowItems.get(position).getsympt());
        b.putString("disDesc",rowItems.get(position).getDesc());
        b.putString("disPath",rowItems.get(position).getImagePath());

        //Add the bundle to the intent.
        ViewDetail.putExtras(b);

        startActivity(ViewDetail);



        Toast toast = Toast.makeText(getActivity().getApplicationContext(),
                "Item " + (position + 1) + ": " + rowItems.get(position).getUserName(),
                Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
        toast.show();
    }

    //Get all the diseas posted in app
    private void getAllDiseas(final View rootV){
        final View rootView=rootV;
        class AddEmployee extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(getActivity(),"checking...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                String dataReceived=s;
                try {
                    JSONObject rootO = new JSONObject(dataReceived.toString());
                    String status=rootO.getString("success");


                    Toast.makeText(getActivity().getApplicationContext(),' '+status, Toast.LENGTH_LONG).show();

                    if(Integer.parseInt(status)==1)
                    {
                        Toast.makeText(getActivity().getApplicationContext(),' '+status, Toast.LENGTH_LONG).show();

                        createListData(rootView, dataReceived);

                    }else
                    {
                        Toast.makeText(getActivity().getApplicationContext(),"Try again!!!", Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e)
                {
                    Toast.makeText(getActivity().getApplicationContext(),"Error="+e,Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();


                RequestHandler rh = new RequestHandler();
               // String res = rh.sendPostRequest("http://10.0.2.2:80/DMDphp/v1/get_All_Dis.php", params);
                String res = rh.sendPostRequest(RefLink.urlGetAllDis, params);
                System.out.println("Res="+res);
                return res;
            }
        }

        AddEmployee ae = new AddEmployee();
        ae.execute();
    }


}
