package com.dmd.project.dmd;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.util.Linkify;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.dmd.project.dmd.model.NavDrawerItem;

import org.json.JSONObject;

import java.sql.Ref;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Created by GreatCoder on 1/24/2016.
 */
public class Login extends Activity implements View.OnClickListener{

    //creating object reference
    TextView signupLink;
    EditText userId,userPass;
    Button lsubmit,lClear;

    String[] navMenuTitles;
    TypedArray navMenuIcons;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);


        lsubmit=(Button)findViewById(R.id.btn_login);
        lClear=(Button)findViewById(R.id.btn_clear_login);

        userId=(EditText)findViewById(R.id.et_email_id);
        userPass=(EditText)findViewById(R.id.et_password);

        //referencing to xml control
        signupLink=(TextView)findViewById(R.id.txt_signup_link);
        signupLink.setText("SignUp");
       // Linkify.addLinks(signupLink, Linkify.ALL);
        signupLink.setOnClickListener(this);
        lsubmit.setOnClickListener(this);
        lClear.setOnClickListener(this);

        userId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!(userId.getText().toString().trim().equals(""))) {
                    userId.setError(null);
                    // Toast.makeText(getApplicationContext(), "Enter Id",
                    // Toast.LENGTH_SHORT).show();
                } else {
                    if (userId.getText().toString().trim().equals("")) {
                        userId.setError("Enter id");
                        // Toast.makeText(getApplicationContext(), "Enter Id",
                        // Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        userPass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!(userPass.getText().toString().trim().equals(""))) {
                    userPass.setError(null);
                    // Toast.makeText(getApplicationContext(), "Enter Id",
                    // Toast.LENGTH_SHORT).show();
                } else {
                    if (userPass.getText().toString().trim().equals("")) {
                        userPass.setError("Enter password");
                        // Toast.makeText(getApplicationContext(), "Enter Id",
                        // Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


    }

    //email validation code
    public static boolean isEmailValid(String email) {
        boolean isValid = false;

        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        CharSequence inputStr = email;

        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches()) {
            isValid = true;
        }
        return isValid;
    }

    @Override
    public void onClick(View view) {

        switch(view.getId())
        {
            case R.id.txt_signup_link:
                //code to open login screen
                Intent openSignUp = new Intent(getApplicationContext(), SignUp.class);
                startActivity(openSignUp);
                break;

            case R.id.btn_login:

                SharedPreferences sp = getSharedPreferences(RefLink.prefStoreName,
                        Context.MODE_PRIVATE);
               if(!sp.getString("Uemail","").equals("")&&!sp.getString("Upassword","").equals(""))
                {
                    Toast.makeText(Login.this,"User Already login!!!", Toast.LENGTH_LONG).show();
                }else {



                   String msg = "Enter ";
                   if (userId.getText().toString().trim().equals("") || isEmailValid(userId.getText().toString().trim())==false) {
                       msg += "  email id,";
                   }
                   if (userPass.getText().toString().trim().equals("")) {
                       msg += " password";
                   }

                   if(msg.equals("Enter "))
                   {
                       msg="";
                   }

                   if(msg.length()!=0){
                       Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                   }else {
                       checkLogin();
                   }
               }

                break;
            case R.id.btn_clear_login:
                    clearAllLoginData();
                break;




        }

    }

    public void clearAllLoginData() {
        userId.setText("");
        userPass.setText("");


        userId.setError(null);
        userPass.setError(null);


    }
    //Adding an employeechecking Login
    private void checkLogin(){

        final String name = userId.getText().toString();
        final String Upassword =userPass.getText().toString();


        class AddEmployee extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(Login.this,"checking...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                String dataReceived=s;
                try {

                    JSONObject root = new JSONObject(dataReceived.toString());
                    String status=root.getString("success");
                    Toast.makeText(Login.this,' '+dataReceived, Toast.LENGTH_LONG).show();

                    if((Integer.parseInt(status)==1))
                    {
                        Toast.makeText(Login.this,' '+status, Toast.LENGTH_LONG).show();

                        // INSTANTIATE SHARED PREFERENCES CLASS
                        SharedPreferences sp = getSharedPreferences(RefLink.prefStoreName,
                                Context.MODE_PRIVATE);
                        // LOAD THE EDITOR – REMEMBER TO COMMIT CHANGES!
                        SharedPreferences.Editor e = sp.edit();
                        e.putString("Uid", root.getString("id"));
                        e.putString("Uname", root.getString("name"));
                        e.putString("Uemail", name);
                        e.putString("Upassword", Upassword);
                        e.commit();


                        // load slide menu items
                        navMenuTitles = getResources().getStringArray(R.array.nav_drawer_items);

                        // nav drawer icons from resources
                        navMenuIcons = getResources()
                                .obtainTypedArray(R.array.nav_drawer_icons);


                        MainActivity m=new MainActivity();

                        navMenuTitles[5]="Logout";
                       // navMenuIcons.getResourceId(5, R.drawable.logout);

                        //navDrawerItems.add(new NavDrawerItem(navMenuTitles[5], navMenuIcons.getResourceId(5, -1)));


                        MainActivity.copyList.set(5,new NavDrawerItem(navMenuTitles[5], navMenuIcons.getResourceId(6, -1)));

                        m.navDrawerItems=MainActivity.copyList;

                        finish();
                    }else
                    {
                        Toast.makeText(Login.this,"Try again!!!", Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e)
                {
                    Toast.makeText(Login.this,"Error="+e,Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                params.put("name",name);
                params.put("Userpassword",Upassword);


                RequestHandler rh = new RequestHandler();
                //String res = rh.sendPostRequest("http://10.0.2.2:80/DMDphp/v1/Login.php", params);
                String res = rh.sendPostRequest(RefLink.urlLogin, params);
                System.out.println("Res="+res);

                return res;
            }
        }

        AddEmployee ae = new AddEmployee();
        ae.execute();
    }


}
