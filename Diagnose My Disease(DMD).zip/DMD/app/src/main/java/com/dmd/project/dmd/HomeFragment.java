package com.dmd.project.dmd;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

/*public class HomeFragment extends Fragment implements View.OnClickListener {

    //initializing the buttons
    Button Skull,Hands,Legs,SpinalCord;

	public HomeFragment(){}
	
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
 
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        //creating the button object and linking them with the xml id
        Skull=(Button)rootView.findViewById(R.id.button);
        Hands=(Button)rootView.findViewById(R.id.Hand);
        Legs=(Button)rootView.findViewById(R.id.Leg);
        SpinalCord=(Button)rootView.findViewById(R.id.spinal);


        Skull.setOnClickListener(this);
        Hands.setOnClickListener(this);
        Legs.setOnClickListener(this);
        SpinalCord.setOnClickListener(this);

        return rootView;
    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.button:

                //calling another intent(Screen) from current activity(screen)
                Intent intent = new Intent(getActivity(), Fracture.class);


                //slide from right to left
                getActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

                startActivity(intent);
                break;
            case R.id.Hand:
                Intent handIntent = new Intent(getActivity(), ActivityB.class);
                startActivity(handIntent);
                break;
            case R.id.Leg:
                Intent legIntent = new Intent(getActivity(), ActivityB.class);
                startActivity(legIntent);
                break;
            case R.id.spinal:
                Intent spinalIntent = new Intent(getActivity(), ActivityB.class);
                startActivity(spinalIntent);
                break;
        }

    }
}*/

public class HomeFragment extends Fragment implements View.OnClickListener {

    ViewPager viewPager;
    CustomSwipeAdapter customSwipeAdapter;
    private int previousState, currentState;

    //code for floating action button
    FloatingActionButton addNewEntry;

    //imageview for login
    //public ImageView LoginButton,LogoutButton;
    SharedPreferences sp;

    public HomeFragment(){}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        //creating objects
        viewPager=(ViewPager) rootView.findViewById(R.id.pageSlide);
        addNewEntry=(FloatingActionButton) rootView.findViewById(R.id.floatingAdd);
       // LoginButton=(ImageView) rootView.findViewById(R.id.imgLogin);
       // LogoutButton=(ImageView) rootView.findViewById(R.id.imgLogout);

        //assigning the click lisener to floating button
        addNewEntry.setOnClickListener(this);
        //LoginButton.setOnClickListener(this);
       // LogoutButton.setOnClickListener(this);

        customSwipeAdapter=new CustomSwipeAdapter(getActivity().getApplicationContext());
        viewPager.setAdapter(customSwipeAdapter);


        return rootView;
    }



    @Override
    public void onClick(View view) {

        switch(view.getId())
        {
            case R.id.floatingAdd:
                sp =getActivity().getApplicationContext().getSharedPreferences(RefLink.prefStoreName,
                        Context.MODE_PRIVATE);
                if(!sp.getString("Uemail","").equals("")&& !sp.getString("Upassword","").equals("")) {

                    Intent openAddNewUser = new Intent(getActivity().getApplicationContext(), AddNewUser.class);
                    startActivity(openAddNewUser);
                }
                else {
                    Toast.makeText(getActivity().getApplicationContext(),"Please Login first",Toast.LENGTH_SHORT).show();
                }
                break;

            /*case R.id.imgLogin:

                 sp = getActivity().getApplicationContext().getSharedPreferences(RefLink.prefStoreName,
                         Context.MODE_PRIVATE);
                if(sp.getString("UEmail","").equals("")&& sp.getString("UPassword","").equals(""))
                {
                    Intent openLogin=new Intent(getActivity().getApplicationContext(),Login.class);
                    startActivity(openLogin);

                }
                else {

                }

                break;

            case R.id.imgLogout:

                // INSTANTIATE SHARED PREFERENCES CLASS
                 sp = getActivity().getApplicationContext().getSharedPreferences(RefLink.prefStoreName,
                        Context.MODE_PRIVATE);
                // LOAD THE EDITOR – REMEMBER TO COMMIT CHANGES!
                SharedPreferences.Editor e = sp.edit();
                e.putString("UEmail", "");
                e.putString("UPassword", "");
                e.commit();

                LoginButton.setVisibility(View.VISIBLE);
                LogoutButton.setVisibility(View.INVISIBLE);

                break;*/
        }

    }


}

