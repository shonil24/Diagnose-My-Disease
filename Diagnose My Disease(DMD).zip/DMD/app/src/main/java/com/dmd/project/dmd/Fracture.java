package com.dmd.project.dmd;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by GreatCoder on 1/3/2016.
 */
public class Fracture extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //setting the layout which is to be displayed
        setContentView(R.layout.activity_fracture);
    }
}
