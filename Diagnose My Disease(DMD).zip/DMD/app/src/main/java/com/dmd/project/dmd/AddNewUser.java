package com.dmd.project.dmd;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

/**
 * Created by GreatCoder on 1/11/2016.
 */
public class AddNewUser extends Activity implements View.OnClickListener {



    Button submitDis,clearData;
    ImageView captureImg;
    EditText disName,disSym,disDisc;

    //constant for image selection
    int REQUEST_CAMERA = 0, SELECT_FILE = 1;

    String ba1;
    String imgFileName="";

    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addnewuser);

        submitDis= (Button) findViewById(R.id.btn_submit);
        clearData= (Button) findViewById(R.id.btn_clear);
        captureImg=(ImageView)findViewById(R.id.img_CapturePic);

        disName=(EditText)findViewById(R.id.et_dis_name);
        disSym=(EditText)findViewById(R.id.et_dis_symptoms);
        disDisc=(EditText)findViewById(R.id.et_dis_discription);

        sp = getSharedPreferences(RefLink.prefStoreName,
                Context.MODE_PRIVATE);

        //adding check listener
        disName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!(disName.getText().toString().trim().equals(""))) {
                    disName.setError(null);
                    // Toast.makeText(getApplicationContext(), "Enter Id",
                    // Toast.LENGTH_SHORT).show();
                } else {
                    if (disName.getText().toString().trim().equals("")) {
                        disName.setError("Enter Diseas Name");
                        // Toast.makeText(getApplicationContext(), "Enter Id",
                        // Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        ///for diseas name
        disSym.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!(disSym.getText().toString().trim().equals(""))) {
                    disSym.setError(null);
                    // Toast.makeText(getApplicationContext(), "Enter Id",
                    // Toast.LENGTH_SHORT).show();
                } else {
                    if (disSym.getText().toString().trim().equals("")) {
                        disSym.setError("Enter Diseas symptoms");
                        // Toast.makeText(getApplicationContext(), "Enter Id",
                        // Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //diseas description
        disDisc.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!(disDisc.getText().toString().trim().equals(""))) {
                    disDisc.setError(null);
                    // Toast.makeText(getApplicationContext(), "Enter Id",
                    // Toast.LENGTH_SHORT).show();
                } else {
                    if (disDisc.getText().toString().trim().equals("")) {
                        disDisc.setError("Enter Diseas Discription");
                        // Toast.makeText(getApplicationContext(), "Enter Id",
                        // Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        submitDis.setOnClickListener(this);
        clearData.setOnClickListener(this);
        captureImg.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {




            case R.id.img_CapturePic:

                //calling method to select image
                selectImage();

                break;

            case R.id.btn_submit:

                String msg="Enter ";
                // Call service here
                if(disName.getText().toString().trim().equals("")){
                    msg+=" Diseas Name,";
                }
                if(disSym.getText().toString().trim().equals("")){
                    msg+=" Diseas symptoms,";
                }
                if(disDisc.getText().toString().trim().equals("")){
                    msg+=" Diseas Discription,";
                }


                if(imgFileName.equals("")){
                    msg+="  image";
                }

                if (msg.equals("Enter "))
                {
                    msg="";
                }
                if(msg.length()!=0){
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                }else{
                    uploadImage();
                }


                break;

            case R.id.btn_clear:
                clearAll();
                break;
        }
    }

    public void clearAll() {
        disName.setText("");
        disSym.setText("");
        disDisc.setText("");
        disName.setError(null);
        disSym.setError(null);
        disDisc.setError(null);
        captureImg.setImageResource(R.drawable.cameradefault);

    }

    //method to send sms
    public void sendSmsBySIntent() {

        // add the phone number in the data

        Uri uri = Uri.parse("smsto:" +"9869018050");//contact no

        Intent smsSIntent = new Intent(Intent.ACTION_SENDTO, uri);

        // add the message at the sms_body extra field

        smsSIntent.putExtra("sms_body", "hello");//sms text

        try{

            startActivity(smsSIntent);

        } catch (Exception ex) {

            Toast.makeText(this, "Your sms has failed...",

                    Toast.LENGTH_LONG).show();

            ex.printStackTrace();

        }

    }

    private void selectImage() {
        final CharSequence[] items = { "Take Photo", "Choose from Library", "Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(AddNewUser.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (items[item].equals("Take Photo")) {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, REQUEST_CAMERA);
                } else if (items[item].equals("Choose from Library")) {
                    Intent intent = new Intent(
                            Intent.ACTION_PICK,
                            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("image/*");
                    startActivityForResult(
                            Intent.createChooser(intent, "Select File"),
                            SELECT_FILE);
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);

        //code to make image in byte
        byte[] ba = bytes.toByteArray();
        ba1 = Base64.encodeToString(ba, Base64.DEFAULT);
        imgFileName=System.currentTimeMillis()+ ".jpg";
        File destination = new File(Environment.getExternalStorageDirectory(),
                imgFileName );

        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        captureImg.setImageBitmap(thumbnail);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {
        Uri selectedImageUri = data.getData();
        String[] projection = { MediaStore.MediaColumns.DATA };
        Cursor cursor = managedQuery(selectedImageUri, projection, null, null,
                null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        cursor.moveToFirst();

        String selectedImagePath = cursor.getString(column_index);

        //code to convert img into byte array
        String fileNameSegments[] = selectedImagePath.split("/");
        imgFileName = fileNameSegments[fileNameSegments.length - 1];



        Bitmap bm;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
       // BitmapFactory.decodeFile(selectedImagePath, options);
        final int REQUIRED_SIZE = 200;
        int scale = 1;
        while (options.outWidth / scale / 2 >= REQUIRED_SIZE
                && options.outHeight / scale / 2 >= REQUIRED_SIZE)
            scale *= 2;
        options.inSampleSize = scale;
        options.inJustDecodeBounds = false;
        bm = BitmapFactory.decodeFile(selectedImagePath, options);

        //code to get the bye array of image which will help us to easyly upload on server
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        // Must compress the Image to reduce image size to make upload easy
        bm.compress(Bitmap.CompressFormat.JPEG, 90, stream);
        byte[] byte_arr = stream.toByteArray();
        // Encode Image to String
        ba1 = Base64.encodeToString(byte_arr, 0);


        captureImg.setImageBitmap(bm);
    }

    //Registering new Diseas
    private void registerNewDiseas(){

       class AddEmployee extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            String userDisName=disName.getText().toString();
            String userDisSym=disSym.getText().toString();
            String userDisDisc=disDisc.getText().toString();

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(AddNewUser.this,"checking...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                String dataReceived=s;
                try {
                    JSONObject root = new JSONObject(dataReceived.toString());
                    String status=root.getString("success");
                    Toast.makeText(AddNewUser.this,' '+status, Toast.LENGTH_LONG).show();

                    if(Integer.parseInt(status)==1)
                    {
                        Toast.makeText(AddNewUser.this,' '+status, Toast.LENGTH_LONG).show();
                        finish();
                    }else
                    {
                        Toast.makeText(AddNewUser.this,"Try again!!!", Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e)
                {
                    Toast.makeText(AddNewUser.this,"Error="+e,Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            protected String doInBackground(Void... v) {

                sp = getSharedPreferences(RefLink.prefStoreName,
                        Context.MODE_PRIVATE);

                HashMap<String,String> params = new HashMap<>();
                params.put("DisName",userDisName);
                params.put("DisSym",userDisSym);
                params.put("DisDisc",userDisDisc );
                params.put("DisPic",imgFileName);
                params.put("UName",sp.getString("Uname","Unknown"));
                params.put("UId",sp.getString("Uid","1"));


                RequestHandler rh = new RequestHandler();
                //String res = rh.sendPostRequest("http://10.0.2.2:80/DMDphp/v1/new_Diseas_Entry.php", params);
                String res = rh.sendPostRequest(RefLink.urlAddnewDis, params);
                System.out.println("Res="+res);
                return res;
            }
        }

        AddEmployee ae = new AddEmployee();
        ae.execute();
    }

//Upload image to server


    private void uploadImage(){

       class UploadImage extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(AddNewUser.this,"Uploading...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();

                try {
                    Toast.makeText(AddNewUser.this,"Sucess="+s,Toast.LENGTH_SHORT).show();
                    //making new diseas entry
                    registerNewDiseas();
                }catch (Exception e)
                {
                    Toast.makeText(AddNewUser.this,"Error="+e,Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                params.put("base64",ba1);
                params.put("ImageName",imgFileName);


                RequestHandler rh = new RequestHandler();
                //String res = rh.sendPostRequest("http://10.0.2.2:80/DMDphp/v1/uploadImage.php", params);
                String res = rh.sendPostRequest(RefLink.urlUploadImage, params);
                System.out.println("Res="+res);
                return res;
            }
        }

        UploadImage uploadImg = new UploadImage();
        uploadImg.execute();
    }


}
