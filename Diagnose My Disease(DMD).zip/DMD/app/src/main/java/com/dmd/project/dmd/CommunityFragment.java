package com.dmd.project.dmd;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class CommunityFragment extends Fragment {

    ListView listView ;

	public CommunityFragment(){}
	
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
 
        View rootView = inflater.inflate(R.layout.fragment_community, container, false);

        // Get ListView object from xml
        listView = (ListView) rootView.findViewById(R.id.list);

        // Defined Array values to show in ListView
        String[] values = new String[] { "Allergies","Arthritis","Asthma",
                "Back pain","Botulism",
                "Cough","Chest pain","Chickenpox",
                "Colds",
                "Diabetes",
                "Earache","Eczema","Gout"

        };//"Heart disease","Hepatitis","Lung cancer","Measles","Melanoma"

        // Define a new Adapter
        // First parameter - Context
        // Second parameter - Layout for the row
        // Third parameter - ID of the TextView to which the data is written
        // Forth - the Array of data

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity().getApplicationContext(),
                android.R.layout.simple_list_item_1, android.R.id.text1, values);


        // Assign adapter to ListView
        listView.setAdapter(adapter);

        // ListView Item Click Listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                // ListView Clicked item index
                int itemPosition     = position;

                // ListView Clicked item value
                String  itemValue    = (String) listView.getItemAtPosition(position);


                switch (itemPosition) {
                    case 0:
                        Intent allergies=new Intent(getActivity().getApplicationContext(),AllergiesActivity.class);
                        startActivity(allergies);

                        break;
                    case 1:
                        Intent Arthritis=new Intent(getActivity().getApplicationContext(),Arthritis.class);
                        startActivity(Arthritis);
                        break;
                    case 2: Intent Asthma=new Intent(getActivity().getApplicationContext(),Asthma.class);
                        startActivity(Asthma);
                        break;
                    case 3: Intent Backpain=new Intent(getActivity().getApplicationContext(),Backpain.class);
                        startActivity(Backpain);
                        break;
                    case 4: Intent Botulism=new Intent(getActivity().getApplicationContext(),Botulism.class);
                        startActivity(Botulism);
                        break;
                    case 5: Intent Cough=new Intent(getActivity().getApplicationContext(),Cough.class);
                        startActivity(Cough);
                        break;
                    case 6: Intent Chestpain=new Intent(getActivity().getApplicationContext(),Chestpain.class);
                        startActivity(Chestpain);
                        break;
                    case 7: Intent Chickenpox=new Intent(getActivity().getApplicationContext(),Chickenpox.class);
                        startActivity(Chickenpox);
                        break;
                    case 8: Intent Colds=new Intent(getActivity().getApplicationContext(),Colds.class);
                        startActivity(Colds);
                        break;
                    case 9:Intent Diabetes=new Intent(getActivity().getApplicationContext(),Diabetes.class);
                        startActivity(Diabetes);
                        break;

                    case 10: Intent Earache=new Intent(getActivity().getApplicationContext(),Earache.class);
                        startActivity(Earache);
                        break;
                    case 11: Intent Eczema=new Intent(getActivity().getApplicationContext(),Eczema.class);
                        startActivity(Eczema);
                        break;
                    case 12: Intent Gout=new Intent(getActivity().getApplicationContext(),Gout.class);
                        startActivity(Gout);
                        break;

                    default:


                        break;
                }

            }

        });

        return rootView;
    }
}
