package com.dmd.project.dmd;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

/**
 * Created by GreatCoder on 2/14/2016.
 */
public class Edit_Diseas extends Activity implements View.OnClickListener  {

    //creating controls
    Button saveEditDis,editData;
    ImageView editCaptureImg;
    EditText disEditName,disEditSym,disEditDisc;
    String disId;

    //constant for image selection
    int REQUEST_CAMERA = 0, SELECT_FILE = 1;

    String ba1;
    String imgFileName="";
    String copyImgFileName="";
    Bundle b ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.edit_diseas);

         b = getIntent().getExtras();

        saveEditDis= (Button) findViewById(R.id.btn_save);
        editData= (Button) findViewById(R.id.btn_edit);
        editCaptureImg=(ImageView)findViewById(R.id.img_editCapturePic);

        saveEditDis.setOnClickListener(this);
        editData.setOnClickListener(this);
        editCaptureImg.setOnClickListener(this);

        disEditName=(EditText)findViewById(R.id.et_edit_Dis_Name);
        disEditSym=(EditText)findViewById(R.id.et_edit_Dis_Symptoms);
        disEditDisc=(EditText)findViewById(R.id.et_edit_Dis_Discription);

        disEditName .setText(b.getString("disName"));
        disEditSym .setText(b.getString("disSympt"));
        disEditDisc .setText(b.getString("disDesc"));

        imgFileName=b.getString("disPath");
        disId=b.getString("disId");

        //setting Image
        copyImgFileName=imgFileName;

        String imgdownloadPath=RefLink.imageDownloadPath+imgFileName;
                Picasso
        .with(Edit_Diseas.this)
                .load(imgdownloadPath)
                .fit() // will explain later
                        .into(editCaptureImg);


        //adding check listener
        disEditName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!(disEditName.getText().toString().trim().equals(""))) {
                    disEditName.setError(null);
                    // Toast.makeText(getApplicationContext(), "Enter Id",
                    // Toast.LENGTH_SHORT).show();
                } else {
                    if (disEditName.getText().toString().trim().equals("")) {
                        disEditName.setError("Enter Diseas Name");
                        // Toast.makeText(getApplicationContext(), "Enter Id",
                        // Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        ///for diseas name
        disEditSym.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!(disEditSym.getText().toString().trim().equals(""))) {
                    disEditSym.setError(null);
                    // Toast.makeText(getApplicationContext(), "Enter Id",
                    // Toast.LENGTH_SHORT).show();
                } else {
                    if (disEditSym.getText().toString().trim().equals("")) {
                        disEditSym.setError("Enter Diseas symptoms");
                        // Toast.makeText(getApplicationContext(), "Enter Id",
                        // Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //diseas description
        disEditDisc.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!(disEditDisc.getText().toString().trim().equals(""))) {
                    disEditDisc.setError(null);
                    // Toast.makeText(getApplicationContext(), "Enter Id",
                    // Toast.LENGTH_SHORT).show();
                } else {
                    if (disEditDisc.getText().toString().trim().equals("")) {
                        disEditDisc.setError("Enter Diseas Discription");
                        // Toast.makeText(getApplicationContext(), "Enter Id",
                        // Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.img_editCapturePic:

                //calling method to select image
                selectImage();

                break;

            case R.id.btn_save:
                String msg="Enter ";

                // Call service here
                if(disEditName.getText().toString().trim().equals("")){
                    msg+=" Diseas Name,";
                }
                if(disEditSym.getText().toString().trim().equals("")){
                    msg+="  Diseas symptoms,";
                }
                if(disEditDisc.getText().toString().trim().equals("")){
                    msg+="  Diseas Discription,";
                }
                if(imgFileName.equals("")){
                    msg+=" new image";
                }

                if(msg.equals("Enter "))
                {
                    msg="";
                }

                if(msg.length()!=0){
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                }else{
                    if(imgFileName.equals(copyImgFileName))
                    {
                        //making new diseas entry
                        UpdateDiseas();
                    }else {
                        uploadImage();
                    }
                }
                break;

            case R.id.btn_edit:
                disEditName.setEnabled(true);
                disEditSym.setEnabled(true);
                disEditDisc.setEnabled(true);
                break;

        }

    }

    private void selectImage() {
        final CharSequence[] items = { "Take Photo", "Choose from Library", "Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(Edit_Diseas.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (items[item].equals("Take Photo")) {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, REQUEST_CAMERA);
                } else if (items[item].equals("Choose from Library")) {
                    Intent intent = new Intent(
                            Intent.ACTION_PICK,
                            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("image/*");
                    startActivityForResult(
                            Intent.createChooser(intent, "Select File"),
                            SELECT_FILE);
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);


        //code to make image in byte
        byte[] ba = bytes.toByteArray();
        ba1 = Base64.encodeToString(ba, Base64.DEFAULT);
        imgFileName=System.currentTimeMillis()+ ".jpg";

        File destination = new File(Environment.getExternalStorageDirectory(),
                imgFileName);

        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        editCaptureImg.setImageBitmap(thumbnail);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {
        Uri selectedImageUri = data.getData();
        String[] projection = { MediaStore.MediaColumns.DATA };
        Cursor cursor = managedQuery(selectedImageUri, projection, null, null,
                null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        cursor.moveToFirst();

        String selectedImagePath = cursor.getString(column_index);

        //code to convert img into byte array
        String fileNameSegments[] = selectedImagePath.split("/");
        imgFileName = fileNameSegments[fileNameSegments.length - 1];


        Bitmap bm;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(selectedImagePath, options);
        final int REQUIRED_SIZE = 200;
        int scale = 1;
        while (options.outWidth / scale / 2 >= REQUIRED_SIZE
                && options.outHeight / scale / 2 >= REQUIRED_SIZE)
            scale *= 2;
        options.inSampleSize = scale;
        options.inJustDecodeBounds = false;
        bm = BitmapFactory.decodeFile(selectedImagePath, options);

        //code to get the bye array of image which will help us to easyly upload on server
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        // Must compress the Image to reduce image size to make upload easy
        bm.compress(Bitmap.CompressFormat.JPEG, 90, stream);
        byte[] byte_arr = stream.toByteArray();
        // Encode Image to String
        ba1 = Base64.encodeToString(byte_arr, 0);


        editCaptureImg.setImageBitmap(bm);
    }

    private void uploadImage(){

        class UploadImage extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(Edit_Diseas.this,"Uploading...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();

                try {
                    Toast.makeText(Edit_Diseas.this, "Sucess=" + s, Toast.LENGTH_SHORT).show();
                    //making new diseas entry
                    UpdateDiseas();
                }catch (Exception e)
                {
                    Toast.makeText(Edit_Diseas.this,"Error="+e,Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                params.put("base64",ba1);
                params.put("ImageName",imgFileName);


                RequestHandler rh = new RequestHandler();
                //String res = rh.sendPostRequest("http://10.0.2.2:80/DMDphp/v1/uploadImage.php", params);
                String res = rh.sendPostRequest(RefLink.urlUploadImage, params);
                System.out.println("Res="+res);
                return res;
            }
        }

        UploadImage uploadImg = new UploadImage();
        uploadImg.execute();
    }

    //Registering new Diseas
    private void UpdateDiseas(){

        class AddEmployee extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            String userDisName=disEditName.getText().toString();
            String userDisSym=disEditSym.getText().toString();
            String userDisDisc=disEditDisc.getText().toString();

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(Edit_Diseas.this,"Updating...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                String dataReceived=s;
                try {
                    JSONObject root = new JSONObject(dataReceived.toString());
                    String status=root.getString("success");
                    Toast.makeText(Edit_Diseas.this,' '+status, Toast.LENGTH_LONG).show();

                    if(Integer.parseInt(status)==1)
                    {
                        Toast.makeText(Edit_Diseas.this,' '+status, Toast.LENGTH_LONG).show();
                        ViewDetailDisAns.getInstance().finish();
                        finish();
                    }else
                    {
                        Toast.makeText(Edit_Diseas.this,"Try again!!!", Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e)
                {
                    Toast.makeText(Edit_Diseas.this,"Error="+e,Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                params.put("dName",userDisName);
                params.put("dSymptoms",userDisSym);
                params.put("dDescription",userDisDisc );
                params.put("dPic",imgFileName);
                params.put("id",disId);


                RequestHandler rh = new RequestHandler();
                //String res = rh.sendPostRequest("http://10.0.2.2:80/DMDphp/v1/updateDiseas.php", params);
                String res = rh.sendPostRequest(RefLink.urlUpdateDis, params);
                System.out.println("Res="+res);
                return res;
            }
        }

        AddEmployee ae = new AddEmployee();
        ae.execute();
    }


}
