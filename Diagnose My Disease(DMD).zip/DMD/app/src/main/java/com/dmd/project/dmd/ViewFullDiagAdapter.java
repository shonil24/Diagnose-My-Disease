package com.dmd.project.dmd;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by GreatCoder on 3/2/2016.
 */
public class ViewFullDiagAdapter extends ArrayAdapter<ViewFullDisDescPOJO> {


        Context context;
        int layoutResourceId;
        ArrayList<ViewFullDisDescPOJO> data = new ArrayList<ViewFullDisDescPOJO>();

        static String diagnoId;

    SharedPreferences sp;



public ViewFullDiagAdapter(Context context, int layoutResourceId,
        ArrayList<ViewFullDisDescPOJO> data) {
        super(context, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.context = context;
        this.data = data;
        }

@Override
public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
    ViewDiagno holder = null;

        if (row == null) {
        LayoutInflater inflater = (LayoutInflater) context
        .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        row = inflater.inflate(layoutResourceId, parent, false);
        holder = new ViewDiagno();
        holder.textName = (TextView) row.findViewById(R.id.textView1);
        holder.textAddress = (TextView) row.findViewById(R.id.textView2);
        holder.textLocation = (TextView) row.findViewById(R.id.textView3);
        holder.btnInvalid = (ImageView) row.findViewById(R.id.img_invalidDigno);
        holder.btnDelete = (ImageView) row.findViewById(R.id.img_deleteDigno);
      //  holder.imageView = (ImageView) row.findViewById(R.id.imageview1);
        row.setTag(holder);
        }
        else {
        holder = (ViewDiagno) row.getTag();
        }
        final ViewFullDisDescPOJO disDescObj = data.get(position);
        holder.textName.setText(disDescObj.getName());
        holder.textAddress.setText(disDescObj.getAddress());
        holder.textLocation.setText(disDescObj.getLocation());

    //making delete button enable n disable
    sp = getContext().getApplicationContext().getSharedPreferences(RefLink.prefStoreName,
            Context.MODE_PRIVATE);
    if(sp.getString("Uid","").equals(disDescObj.getUserId().toString())) {
        holder.btnDelete.setVisibility(View.VISIBLE);

    }
    else
    {
        holder.btnDelete.setVisibility(View.INVISIBLE);

    }

        holder.btnInvalid.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                    // TODO Auto-generated method stub
                    Log.i("Edit Button Clicked", "**********");
                    Toast.makeText(context, "Invalidate button Clicked",
                            Toast.LENGTH_LONG).show();

                diagnoId=disDescObj.getid();

                AddEmployee ae = new AddEmployee();
                ae.execute();
                ViewDetailDisAns vd;
                vd = new ViewDetailDisAns();

                vd.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //to remove data from array list
                        data.remove(disDescObj);
                        //to notify/say list view that data has been changed
                        notifyDataSetChanged();

                    }
                });

            }
        });

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v) {
                // TODO Auto-generated method stub
                Log.i("Delete Button Clicked", "**********");
                Toast.makeText(context, "Delete button Clicked",
                Toast.LENGTH_LONG).show();

            diagnoId=disDescObj.getid();

            //DeleteDiagnosRes(disDescObj,context);
               AddEmployee ae = new AddEmployee();
                ae.execute();
            ViewDetailDisAns vd;
            vd = new ViewDetailDisAns();

            vd.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //to remove data from array list
                    data.remove(disDescObj);
                    //to notify/say list view that data has been changed
                    notifyDataSetChanged();

                }
            });

        }
        });

       /* holder.imageView.setOnClickListener(new View.OnClickListener() {

@Override
public void onClick(View v) {
        // TODO Auto-generated method stub
        Log.i("image Clicked", "**********");
        Toast.makeText(context, "image Clicked",
        Toast.LENGTH_LONG).show();
        }
        });*/
        return row;

        }

static class ViewDiagno {
    TextView textName;
    TextView textAddress;
    TextView textLocation;
    ImageView btnInvalid;
    ImageView btnDelete;
   // ImageView imageView;
}

   // private void DeleteDiagnosRes(ViewFullDisDescPOJO DeleteObj, final Context ctx){

        //final ViewFullDisDescPOJO disDescObj=DeleteObj;
       // final Context Discontext=ctx;
        class AddEmployee extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(context,"checking...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                String dataReceived=s;
                try {
                    JSONObject root = new JSONObject(dataReceived.toString());
                    String status=root.getString("success");
                    Toast.makeText(context, ' ' + status, Toast.LENGTH_LONG).show();

                    if(Integer.parseInt(status)==1)
                    {
                        Toast.makeText(context,' '+status, Toast.LENGTH_LONG).show();

                    }else
                    {
                        Toast.makeText(context,"Try again!!!", Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e)
                {
                    Toast.makeText(context,"Error="+e,Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                params.put("id",diagnoId);

                RequestHandler rh = new RequestHandler();
                //String res = rh.sendPostRequest("http://10.0.2.2:80/DMDphp/v1/deleteDiagnos.php", params);
                String res = rh.sendPostRequest(RefLink.urlDeleteDiagno, params);
                System.out.println("Res=" + res);


                return res;
            }
        }

       // AddEmployee ae = new AddEmployee();
        //ae.execute();
  //  }

}
