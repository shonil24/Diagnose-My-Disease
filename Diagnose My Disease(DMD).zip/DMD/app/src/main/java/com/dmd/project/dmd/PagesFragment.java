package com.dmd.project.dmd;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class PagesFragment extends Fragment {

    ListView listView ;

	public PagesFragment(){}
	
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
 
        View rootView = inflater.inflate(R.layout.fragment_pages, container, false);

        // Get ListView object from xml
        listView = (ListView) rootView.findViewById(R.id.listaccid);

        // Defined Array values to show in ListView
        String[] values1 = new String[] { "CPR",
                "Burns",
                "Sunburn",
                "Bleeding",
                "Cuts And Scrapes",
                "Bee Stings",
                "Fractures",
                "shock",
                "Frostbite"
        };

        // Define a new Adapter
        // First parameter - Context
        // Second parameter - Layout for the row
        // Third parameter - ID of the TextView to which the data is written
        // Forth - the Array of data

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_list_item_1, android.R.id.text1, values1);


        // Assign adapter to ListView
        listView.setAdapter(adapter);

        // ListView Item Click Listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                // ListView Clicked item index
                int itemPosition     = position;

                // ListView Clicked item value
                String  itemValue    = (String) listView.getItemAtPosition(position);

                switch(position)
                {
                    case 0:
                        Intent cpr=new Intent(getActivity().getApplicationContext(),CPR.class);
                        startActivity(cpr);
                        break;
                    case 1:
                        Intent burns=new Intent(getActivity().getApplicationContext(),Burns.class);
                        startActivity(burns);
                        break;

                    case 2:
                        Intent sunBurns=new Intent(getActivity().getApplicationContext(),SunBurn.class);
                        startActivity(sunBurns);
                        break;
                    case 3:
                        Intent bleed=new Intent(getActivity().getApplicationContext(),Bleeding.class);
                        startActivity(bleed);
                        break;
                    case 4:
                        Intent cuts=new Intent(getActivity().getApplicationContext(),Cuts.class);
                        startActivity(cuts);
                        break;
                    case 5:
                        Intent bee=new Intent(getActivity().getApplicationContext(),Bee.class);
                        startActivity(bee);
                        break;
                    case 6:

                        Intent frac=new Intent(getActivity().getApplicationContext(),Fracture.class);
                        startActivity(frac);

                        break;
                    case 7:
                        Intent shocks=new Intent(getActivity().getApplicationContext(),Shock.class);
                        startActivity(shocks);
                        break;
                    case 8:
                        Intent fros=new Intent(getActivity().getApplicationContext(),Frostbite.class);
                        startActivity(fros);
                        break;

                }

            }

        });

        return rootView;
    }
}
