package com.dmd.project.dmd;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by GreatCoder on 1/31/2016.
 */
public class CustomListViewDMDAdapter extends ArrayAdapter<RowItem> {

    Context context;
    LayoutInflater inflater;
    List<RowItem> data = null;
    ArrayList<RowItem> arraylist;


    public CustomListViewDMDAdapter(Context context, int resourceId,
                                    List<RowItem> items) {
        super(context, resourceId, items);
        this.context = context;
        //to get the list data and  update
        this.data = items;
        inflater = LayoutInflater.from(context);
        this.arraylist = new ArrayList<RowItem>();
        this.arraylist.addAll(items);

    }

    /*private view holder class*/
    private class ViewHolder {
        ImageView imageView;
        TextView txtTitle;
        TextView txtDesc;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        RowItem rowItem = getItem(position);

        LayoutInflater mInflater = (LayoutInflater) context
                .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.viewitems, null);
            holder = new ViewHolder();
            holder.txtDesc = (TextView) convertView.findViewById(R.id.desc);
            holder.txtTitle = (TextView) convertView.findViewById(R.id.title);
            holder.imageView = (ImageView) convertView.findViewById(R.id.icon);
            convertView.setTag(holder);
        } else
            holder = (ViewHolder) convertView.getTag();

        holder.txtDesc.setText(rowItem.getsympt());
        holder.txtTitle.setText(rowItem.getTitle());
        //holder.imageView.setImageResource(rowItem.getImageId());

        Picasso
                .with(context)
                .load(RefLink.imageDownloadPath+rowItem.getImagePath())
                .fit() // will explain later
                .into(holder.imageView);

        return convertView;
    }

    // Filter Class
    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        data.clear();
        if (charText.length() == 0) {
            data.addAll(arraylist);
        }
        else
        {
            for (RowItem wp : arraylist)
            {
                if (wp.getTitle().toLowerCase(Locale.getDefault()).contains(charText))
                {
                    data.add(wp);
                }
            }
        }
        notifyDataSetChanged();
    }
}
