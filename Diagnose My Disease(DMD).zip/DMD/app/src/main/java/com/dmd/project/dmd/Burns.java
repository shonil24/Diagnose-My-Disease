package com.dmd.project.dmd;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by GreatCoder on 3/19/2016.
 */
public class Burns extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //setting view
        setContentView(R.layout.burns);
    }


}
