package com.dmd.project.dmd;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by GreatCoder on 3/17/2016.
 */
public class Earache  extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.earache);
    }
}

