package com.dmd.project.dmd;

import android.app.Fragment;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class PhotosFragment extends Fragment {

    ListView userList;
    DeleteAdapter userAdapter;
    ArrayList<DeletePOJO> userArray = new ArrayList<DeletePOJO>();

    public PhotosFragment(){}
	
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
 
        View rootView = inflater.inflate(R.layout.fragment_photos, container, false);


        getAllDiseasForDelete(rootView);

        return rootView;
    }

    //List of all the diseas posted and user can perform delete operation
    private void getAllDiseasForDelete(final View rootV){
        final View rootView=rootV;
        class AddEmployee extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(getActivity(),"checking...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                String dataReceived=s;
                try {
                    JSONObject rootO = new JSONObject(dataReceived.toString());
                    System.out.println("Data="+dataReceived);
                    String status=rootO.getString("success");
                    Toast.makeText(getActivity().getApplicationContext(), ' ' + status, Toast.LENGTH_LONG).show();

                    if(Integer.parseInt(status)==1)
                    {
                        Toast.makeText(getActivity().getApplicationContext(),' '+status, Toast.LENGTH_LONG).show();
                        createListData(rootView, dataReceived);
                    }else
                    {
                        Toast.makeText(getActivity().getApplicationContext(),"Try again!!!", Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e)
                {
                    Toast.makeText(getActivity().getApplicationContext(),"Error="+e,Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();


                RequestHandler rh = new RequestHandler();
               // String res = rh.sendPostRequest("http://10.0.2.2:80/DMDphp/v1/get_All_Dis.php", params);
                String res = rh.sendPostRequest(RefLink.urlGetAllDis, params);
                System.out.println("Res="+res);
                return res;
            }
        }

        AddEmployee ae = new AddEmployee();
        ae.execute();
    }

    public void createListData(View rootView,String dataReceived) throws JSONException, IOException {
        JSONObject root = new JSONObject(dataReceived.toString());
        JSONArray jArr = root.getJSONArray("diseas");

        for (int i = 0; i < jArr.length(); i++) {

            JSONObject Arrdata = jArr.getJSONObject(i);

            DeletePOJO item = new DeletePOJO(((Arrdata.getString("dPic"))),Arrdata.getString("id"), Arrdata.getString("dName"), Arrdata.getString("dSymptoms"), Arrdata.getString("uId"));
            userArray.add(item);

            userAdapter = new DeleteAdapter(getActivity().getApplicationContext(), R.layout.viewdeleteitems,
                    userArray,getActivity());
            userList = (ListView)rootView.findViewById(R.id.listDelete);
            userList.setItemsCanFocus(false);
            userList.setAdapter(userAdapter);

        }

    }

}
