package com.dmd.project.dmd;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by GreatCoder on 3/9/2016.
 */
public class ViewDetailDisAns extends Activity implements View.OnClickListener {

    public ListView diagAnsList;
    ViewFullDiagAdapter userAdapter;
    ArrayList<ViewFullDisDescPOJO> userArray = new ArrayList<ViewFullDisDescPOJO>();

    Button AnsNow;
    TextView lbldisName,getLbldisSympt,getLbldisDesc;
    ImageView EditQ;
    SharedPreferences sp;
    Bundle b;

    static ViewDetailDisAns activityA;

    String disName,disSympt,disDesc,disPath,disId;

    public static ViewDetailDisAns getInstance(){
        return   activityA;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.useranswerdiseas);

        //getting the reference of the current activity
        activityA = this;

        lbldisName = (TextView) findViewById(R.id.textView5);
        getLbldisSympt  = (TextView) findViewById(R.id.textView4);
        getLbldisDesc = (TextView) findViewById(R.id.textView6);

        Bundle b = getIntent().getExtras();
        lbldisName .setText(b.getString("disName"));
        getLbldisSympt .setText(b.getString("disSympt"));
        getLbldisDesc .setText(b.getString("disDesc"));

        disName=b.getString("disName");
        disSympt=b.getString("disSympt");
        disDesc=b.getString("disDesc");
        disPath=b.getString("disPath");
        disId=b.getString("disId");


        AnsNow=(Button)findViewById(R.id.btnAnswer);
        EditQ=(ImageView)findViewById(R.id.imgEditQuestion);
        AnsNow.setOnClickListener(this);
        EditQ.setOnClickListener(this);
        // INSTANTIATE SHARED PREFERENCES CLASS
         sp = getSharedPreferences(RefLink.prefStoreName,
                Context.MODE_PRIVATE);
        if(sp.getString("Uid","").equals("")) {
            EditQ.setVisibility(View.INVISIBLE);
        }
        else
        {
            EditQ.setVisibility(View.VISIBLE);
        }


        getDiseasSolutions();
    }


    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.btnAnswer:

                Intent OpenAns=new Intent(getApplicationContext(),AnswerNow.class);

                //Create a bundle object
                b = new Bundle();

                //Inserts a String value into the mapping of this Bundle
                b.putString("disId",disId);
                //Add the bundle to the intent.
                OpenAns.putExtras(b);

                startActivity(OpenAns);

                break;

            case R.id.imgEditQuestion:

                Intent openEditQuestion=new Intent(getApplicationContext(),Edit_Diseas.class);

                //passing data
                //Create a bundle object
                 b = new Bundle();

                //Inserts a String value into the mapping of this Bundle
                b.putString("disId",disId);
                b.putString("disName",disName);
                b.putString("disSympt",disSympt);
                b.putString("disDesc",disDesc);
                b.putString("disPath",disPath);

                //Add the bundle to the intent.
                openEditQuestion.putExtras(b);

                startActivity(openEditQuestion);


                break;
        }
    }


    private void getDiseasSolutions(){


        class AddEmployee extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(ViewDetailDisAns.this,"checking...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                String dataReceived=s;
                try {
                    JSONObject root = new JSONObject(dataReceived.toString());
                    String status=root.getString("success");
                    Toast.makeText(ViewDetailDisAns.this, ' ' + status, Toast.LENGTH_LONG).show();

                    if(Integer.parseInt(status)==1)
                    {
                        Toast.makeText(ViewDetailDisAns.this,' '+status, Toast.LENGTH_LONG).show();
                        createDiagnosListData(dataReceived);
                    }else
                    {
                        Toast.makeText(ViewDetailDisAns.this,"Try again!!!", Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e)
                {
                    Toast.makeText(ViewDetailDisAns.this,"Error="+e,Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                params.put("diseasId",disId);

                RequestHandler rh = new RequestHandler();
                //String res = rh.sendPostRequest("http://10.0.2.2:80/DMDphp/v1/get_DisDiagnos.php", params);
                String res = rh.sendPostRequest(RefLink.urlGetAllDisDiagno, params);
                System.out.println("Res="+res);
                return res;
            }
        }

        AddEmployee ae = new AddEmployee();
        ae.execute();
    }

    public void createDiagnosListData(String dataReceived) throws JSONException, IOException {
        JSONObject root = new JSONObject(dataReceived.toString());
        JSONArray jArr = root.getJSONArray("diagnose");

        for (int i = 0; i < jArr.length(); i++) {

            JSONObject Arrdata = jArr.getJSONObject(i);

            ViewFullDisDescPOJO item = new ViewFullDisDescPOJO(Arrdata.getString("id"),Arrdata.getString("uId"),Arrdata.getString("diseasId"),  Arrdata.getString("digSol"), Arrdata.getString("quickMedi"), Arrdata.getString("docRef"));
            userArray.add(item);

            userAdapter = new ViewFullDiagAdapter(ViewDetailDisAns.this, R.layout.viewfulldiagno,
                    userArray);
            diagAnsList = (ListView)findViewById(R.id.lstAnswer);

            // diagAnsList.setItemsCanFocus(false);
            diagAnsList.setAdapter(userAdapter);


        }

    }


}
