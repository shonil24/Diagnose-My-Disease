package com.dmd.project.dmd;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.HashMap;

/**
 * Created by GreatCoder on 3/9/2016.
 */
public class AnswerNow extends Activity implements View.OnClickListener {

    Button submitDiagno;

    EditText solution,docRef,quickMedi;

    Bundle b ;

    String disId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.answernow);

        b = getIntent().getExtras();

        submitDiagno= (Button) findViewById(R.id.btn_submit_diagno);

        submitDiagno.setOnClickListener(this);

        solution=(EditText)findViewById(R.id.et_Diag_solution);
        docRef=(EditText)findViewById(R.id.et_Diag_DocRef);
        quickMedi=(EditText)findViewById(R.id.et_Diag_QuickMedi);

        b = getIntent().getExtras();
        disId=b.getString("disId");

        //adding check listener
        solution.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!(solution.getText().toString().trim().equals(""))) {
                    solution.setError(null);
                    // Toast.makeText(getApplicationContext(), "Enter Id",
                    // Toast.LENGTH_SHORT).show();
                } else {
                    if (solution.getText().toString().trim().equals("")) {
                        solution.setError("Enter Diseas solution");
                        // Toast.makeText(getApplicationContext(), "Enter Id",
                        // Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


    }

    //Posting User answer for perticular diseas
    private void submitANSWER(){


        class AddEmployee extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            String digSolu=solution.getText().toString();
            String quickMedicine=quickMedi.getText().toString();
            String docRefer=docRef.getText().toString();

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(AnswerNow.this,"checking...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                String dataReceived=s;
                try {
                    JSONObject root = new JSONObject(dataReceived.toString());
                    String status=root.getString("success");
                    Toast.makeText(AnswerNow.this, ' ' + status, Toast.LENGTH_LONG).show();

                    if(Integer.parseInt(status)==1)
                    {
                        Toast.makeText(AnswerNow.this,' '+status, Toast.LENGTH_LONG).show();
                        finish();
                    }else
                    {
                        Toast.makeText(AnswerNow.this,"Try again!!!", Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e)
                {
                    Toast.makeText(AnswerNow.this,"Error="+e,Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                // INSTANTIATE SHARED PREFERENCES CLASS
                SharedPreferences sp = getSharedPreferences(RefLink.prefStoreName,
                        Context.MODE_PRIVATE);
                params.put("uId", sp.getString("Uid",""));
                params.put("diseasId",disId);
                params.put("digSol",digSolu);
                params.put("quickMedi",quickMedicine);
                params.put("docRef",docRefer);



                RequestHandler rh = new RequestHandler();
              //  String res = rh.sendPostRequest("http://10.0.2.2:80/DMDphp/v1/newDiseasDiagnos.php", params);
                String res = rh.sendPostRequest(RefLink.urlAnswerDis, params);
                System.out.println("Res="+res);
                return res;
            }
        }

        AddEmployee ae = new AddEmployee();
        ae.execute();
    }


    @Override
    public void onClick(View view) {
            switch (view.getId()) {

                case R.id.btn_submit_diagno:

                    String msg="";
                    // Call service here
                    if(solution.getText().toString().trim().equals("")){
                        msg+="Enter Diseas solution";
                    }
                    if(msg.equals("Enter "))
                    {
                        msg="";
                    }
                    if(msg.length()!=0){
                        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    }else{
                        submitANSWER();
                    }


                    break;
            }

        }
}
