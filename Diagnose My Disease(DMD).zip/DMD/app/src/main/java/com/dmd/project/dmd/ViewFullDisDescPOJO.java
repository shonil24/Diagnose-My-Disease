package com.dmd.project.dmd;

/**
 * Created by GreatCoder on 3/2/2016.
 */
public class ViewFullDisDescPOJO {

    String id;
    String name;
    String address;
    String location;
    String UserId;
    String DignoDisId;

    //dis solution
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    //quick medi
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    //doc ref
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
    //disId
    public String getid() {
        return id;
    }

    public void setid(String id) {
        this.id = id;
    }
    //userId
    public String getUserId() {
        return UserId;
    }

    public void setUserId(String UserId) {
        this.UserId = UserId;
    }
    //DignoId
    public String getDisId() {
        return DignoDisId;
    }

    public void setDisId(String DignoDisId) {
        this.DignoDisId = DignoDisId;
    }


    public ViewFullDisDescPOJO(String id,String UserId,String DignoDisId, String name, String address, String location) {
        super();

        this.id = id;
        this.UserId=UserId;
        this.DignoDisId=DignoDisId;
        this.name = name;
        this.address = address;
        this.location = location;
    }

}
